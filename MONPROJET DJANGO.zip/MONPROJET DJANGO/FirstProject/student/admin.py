from django import forms
from django.contrib import admin
from .models import User

# Formulaire personnalisé pour le modèle User
class UserAdminForm(forms.ModelForm):
    class Meta:
        model = User
        fields = '__all__'
        # Définition des widgets pour styliser l'affichage des champs
        widgets = {
            'name': forms.TextInput(attrs={'style': 'width: 200px;'}),
            'prenom': forms.TextInput(attrs={'style': 'width: 200px;'}),
            'email': forms.EmailInput(attrs={'style': 'width: 200px;'}),
            'telephone': forms.TextInput(attrs={'style': 'width: 200px;'}),
            'adresse': forms.TextInput(attrs={'style': 'width: 200px;'}),
            'classe_niveau': forms.Select(attrs={'style': 'width: 200px;'}),
        }

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    # Colonnes à afficher dans la liste des utilisateurs
    list_display = ('id', 'name', 'prenom', 'email', 'telephone', 'adresse')
    # Liens cliquables pour l'ID
    list_display_links = ('id',)
    # Champs de recherche pour filtrer les utilisateurs
    search_fields = ('name', 'prenom', 'id', 'telephone')
    # Colonnes éditables directement dans la liste
    list_editable = ('name', 'prenom', 'email', 'telephone', 'adresse')
    # Nombre d'utilisateurs affichés par page dans la liste
    list_per_page = 10
    # Actions disponibles pour la sélection d'utilisateurs
    actions = ['delete_selected']

    # Personnalisation du style CSS de l'interface d'administration
    class Media:
        css = {
            'all': ('css/admin_custom.css',)  # Assurez-vous que le chemin est correct
        }
        
    # Surcharge de la méthode get_actions pour permettre la suppression d'un utilisateur
    def get_actions(self, request):
        actions = super().get_actions(request)
        # Suppression de l'action par défaut
        del actions['delete_selected']
        return actions

    # Fonction personnalisée pour la suppression d'un utilisateur
    def supprimer_utilisateur(self, request, queryset):
        # Votre logique de suppression ici
        queryset.delete()
    
    # Nom de l'action personnalisée
    supprimer_utilisateur.short_description = "Supprimer les utilisateurs sélectionnés"    
