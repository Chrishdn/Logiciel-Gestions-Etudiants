from django.db import models

class User(models.Model):
    name = models.CharField(max_length=70)
    prenom = models.CharField(max_length=70, null=False, default='')
    email = models.CharField(max_length=50)
    telephone = models.CharField(max_length=15, null=False, default='')  
    adresse = models.CharField(max_length=255)
    classe_niveau = models.CharField(max_length=50, null=False, default='')  
