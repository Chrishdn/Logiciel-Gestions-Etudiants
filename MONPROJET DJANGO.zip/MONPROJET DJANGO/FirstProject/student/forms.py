from django import forms
from .models import User

# Choix disponibles pour la classe/niveau
CLASSE_NIVEAU_CHOICES = [
    ('', 'Choisir...'),  # Option par défaut vide
    ('BDW1', 'Bachelor Développement Web 1ère année'),
    ('BDW2', 'Bachelor Développement Web 2ème année'),
    ('BDW3', 'Bachelor Développement Web 3ème année'),
    ('BDIA1', 'Bachelor Data IA 1ère année'),
    ('BDIA2', 'Bachelor Data IA 2ème année'),
    ('BDIA3', 'Bachelor Data IA 3ème année'),
    ('BWU1', 'Bachelor Webmarketing & UX 1ère année'),
    ('BWU2', 'Bachelor Webmarketing & UX 2ème année'),
    ('BWU3', 'Bachelor Webmarketing & UX 3ème année'),
]

# Formulaire d'inscription d'un étudiant
class StudentRegistration(forms.ModelForm):
    classe_niveau = forms.ChoiceField(
        choices=CLASSE_NIVEAU_CHOICES, 
        required=True, 
        label='Classe/Niveau', 
        widget=forms.Select(attrs={
            'class': 'form-control', 
            'style': 'border-radius: 20px; width: 50%;'  # Bords arrondis et largeur réduite pour classe_niveau
        })
    )

    class Meta:
        model = User
        # Champs à inclure dans le formulaire
        fields = ['name', 'prenom', 'email', 'telephone', 'adresse', 'classe_niveau']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'style': 'border-radius: 20px;'}),
            'prenom': forms.TextInput(attrs={'class': 'form-control', 'style': 'border-radius: 20px;'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'style': 'border-radius: 20px;'}),
            'telephone': forms.TextInput(attrs={'class': 'form-control', 'style': 'border-radius: 20px;'}),
            'adresse': forms.TextInput(attrs={'class': 'form-control', 'style': 'border-radius: 20px;'}),
            # Le widget pour 'classe_niveau' est déjà défini avec des bords arrondis ci-dessus
        }
