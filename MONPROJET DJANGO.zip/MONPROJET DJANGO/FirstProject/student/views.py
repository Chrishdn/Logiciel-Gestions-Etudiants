from django.shortcuts import render, HttpResponseRedirect
from .forms import StudentRegistration
from .models import User
from django.db.models import Q  # Importation Q pour les requêtes complexes

# Cette fonction permet d'ajouter et d'afficher les informations
def add_Show(request): 
    if request.method == 'POST':
        fm = StudentRegistration(request.POST)
        if fm.is_valid():
            # Création d'une nouvelle instance User sans le champ 'password'
            reg = fm.save(commit=False)  # Utilisation de 'commit=False' pour obtenir l'objet sans le sauvegarder immédiatement dans la base de données
            reg.save()  # Sauvegarde de l'objet dans la base de données
            fm = StudentRegistration()  # Réinitialisation du formulaire après la sauvegarde
    else:
        fm = StudentRegistration()

    # Recherche étendue
    query = request.GET.get("search")
    if query:
        stud = User.objects.filter(
            Q(name__icontains=query) | 
            Q(prenom__icontains=query) | 
            Q(id__icontains=query) | 
            Q(telephone__icontains=query)
        )
    else:
        stud = User.objects.all()

    return render(request, 'student/addandshow.html', {'form': fm, 'stu': stud})

# Cette fonction permet de modifier les informations
def update_data(request, id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        fm = StudentRegistration(request.POST, instance=pi)
        if fm.is_valid():
            fm.save()
    else:
        pi = User.objects.get(pk=id)
        fm = StudentRegistration(instance=pi)       
    return render(request, 'student/updatestudent.html', {'form': fm})

# Cette fonction permet de supprimer les données
def delete_data(request, id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        pi.delete()
        return HttpResponseRedirect('/')
